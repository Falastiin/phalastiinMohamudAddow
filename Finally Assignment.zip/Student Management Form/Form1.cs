﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Student_Management_Form
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void StudentNamelabel_Click(object sender, EventArgs e)
        {

        }

        private void StudentIDlabel_Click(object sender, EventArgs e)
        {

        }

        private void Exitbutton_Click(object sender, EventArgs e)
        {
            // Close the form.
            this.Close();
        }

        private void Clearbutton_Click(object sender, EventArgs e)
        {
            NametextBox.Text = " ";
            IDtextBox.Text = "  ";
            AgetextBox.Text = " ";
        }

        private void Submidbutton_Click(object sender, EventArgs e)
        {
            try
            {

                // Declaring variables

                string std_name, courses = "", fullstdinfo, Extra = " ", gender = " ";
                int std_age, std_id;
                // initialing student name from input textbox
                double num;
                std_name = NametextBox.Text;

                if (double.TryParse(NametextBox.Text, out num))
                {
                    MessageBox.Show("invalid name!");

                    return;
                }
                // validating and parsing for id_textbox  using try parse
                if (int.TryParse(IDtextBox.Text, out std_id))
                {
                    //  MessageBox.Show("succes");
                }
                 else
                {
                    MessageBox.Show("waxan lambar ahayn lama ogolo");
                }
                // validating and parsing for  age_textbox using try parse
                std_age = int.Parse(AgetextBox.Text);
                if (std_age >= 18 & std_age <= 35)
                {
                    //  MessageBox.Show("succes");

                }
                else
                {
                    MessageBox.Show("so geli inta u dhaxayso 18 ilaa 35");
                    return;
                }


                // male and radio checked
                if (Male.Checked)
                {
                    gender = "Male ";
                }
                else if (Female.Checked)
                {
                    gender = "Female";
                }
                else
                {
                    MessageBox.Show("wa inaad dorata mid ka kid ah jinsiga");
                }



                // list box 
                if (CoursesList.SelectedIndex != -1)
                {
                    courses = CoursesList.SelectedItem.ToString();
                }



                // Extra_curricular checked 
                if (ExtraBox.Checked)
                {
                    Extra = "Yes";
                }
                else
                {
                    Extra = "No";
                }
                fullstdinfo = "Name: " + std_name + " \n  ID: " + std_id + "\n  Age: " + std_age + "\n  Gender: " + gender + "\n   Extra_curricular:  " + Extra + "\n   courses:" + courses;
                
                Result.Text = fullstdinfo;


                NametextBox.Focus();
            }
            catch(Exception Qaladaadka){
                MessageBox.Show(Qaladaadka.Message);
            }

        }

        private void CoursesList_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void NametextBox_TextChanged(object sender, EventArgs e)
        {

        }
    }
}